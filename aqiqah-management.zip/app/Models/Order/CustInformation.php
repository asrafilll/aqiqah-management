<?php

namespace App\Models\Order;

use Illuminate\Database\Eloquent\Model;

class CustInformation extends Model
{
    protected $guarded = [];
}
