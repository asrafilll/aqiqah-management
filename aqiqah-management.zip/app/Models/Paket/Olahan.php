<?php

namespace App\Models\Paket;

use Illuminate\Database\Eloquent\Model;

class Olahan extends Model
{
    //
}
