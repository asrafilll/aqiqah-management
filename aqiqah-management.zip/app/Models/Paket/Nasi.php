<?php

namespace App\Models\Paket;

use Illuminate\Database\Eloquent\Model;

class Nasi extends Model
{
    //
}
