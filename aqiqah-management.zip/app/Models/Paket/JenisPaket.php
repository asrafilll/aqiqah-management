<?php

namespace App\Models\Paket;

use Illuminate\Database\Eloquent\Model;

class JenisPaket extends Model
{
    //
}
