<!-- <div class="div-custom">
	<div class="row">
		<div class="col-md-6" id="div-olahan_daging" style="display: none">
			<label>Olahan Daging</label>
			<select name="olahan_daging" class="form-control">

			</select>
		</div>
		<div class="col-md-6" id="div-olahan_jeroan" style="display: none;">
			<label>Olahan Jeroan</label>
			<select name="olahan_jeroan" class="form-control">

			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6" id="div-menu_pilihan1" style="display: none;">
			<label>Menu Pilihan</label>
			<select name="menu_pilihan1" class="form-control">

			</select>
		</div>
		<div class="col-md-6" id="div-menu_pilihan2" style="display: none;">
			<label>Menu Pilihan 2</label>
			<select name="menu_pilihan2" class="form-control">

			</select>
		</div>
	</div>
	<div class="row" id="div-nasi" style="display: none;">
		<div class="col-md-4">
			<label>Nasi</label>
			<select name="nasi" class="form-control">

			</select>
		</div>
	</div>
</div>
<a href="javascript:void(0)" class="btn btn-primary btn-sm" id="btnClonePaket">Tambah</a> -->