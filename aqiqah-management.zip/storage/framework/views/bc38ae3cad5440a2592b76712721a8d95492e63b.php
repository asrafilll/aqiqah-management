<div class="card card-body card_package" id="card_package_<?php echo e($id); ?>">
    <div class="floating_button d-none">
        <button class="btn btn-primary btn_add_package"
            type="button" id="btn_add_package_<?php echo e($id); ?>"
            onclick="addPackage()"
        >
            +
        </button>
    </div>
    <div class="form-row">
        <div class="col">
            <label for="">Jenis Paket</label>
            <select name="package[<?php echo e($id); ?>][package_id]" class="form-control"
                onchange="selectDetailPackage(this.value, <?php echo e($id); ?>)" id="">
                <option value="" selected disabled>-- Pilih Paket --</option>
                <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pack->id); ?>"><?php echo e($pack->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-row" id="target-package-detail-<?php echo e($id); ?>"></div>
</div><?php /**PATH C:\Users\Lenovo Yoga370\Documents\Programming\Personal\aqiqah-management\resources\views/order/partials/card-package.blade.php ENDPATH**/ ?>