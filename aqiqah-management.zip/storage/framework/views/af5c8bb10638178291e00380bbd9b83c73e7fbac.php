<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
            <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link">
                <i class="nav-icon fa fa-pie-chart"></i>
                <p>
                    Dashboard
                </p>
            </a>
        </li>
        <li class="nav-item <?php echo e(\Request::is('order*') ? 'menu-open' : ''); ?>" class="menu <?php echo $__env->yieldContent('order'); ?>">
            <a href="#" class="nav-link <?php echo $__env->yieldContent('order'); ?>">
                <i class="nav-icon fa fa-book"></i>
                <p>
                    Order Management
                    <i class="right fa fa-angle-left"></i>
                </p>
            </a>
            <ul class="nav nav-treeview" style="padding-left: 25px;">
                <li class="nav-item <?php echo e(\Request::routeIs('order.create') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('order.create')); ?>" class="nav-link" style="width: 100%">
                        <p>New Order</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('order.index')); ?>" class="nav-link" style="width: 100%">
                        <p>Order List</p>
                    </a>
                </li>
            </ul>
        </li>
        
        <li class="nav-item custom-auth-sidebar <?php echo e(\Request::is('users*') || \Request::is('branch*') || \Request::is('role*') ? 'menu-open' : ''); ?>" class="menu">
            <a href="#" class="nav-link">
                <i class="nav-icon fa fa-users"></i>
                <p>
                    User Management
                    <i class="right fa fa-angle-left"></i>
                </p>
            </a>
            <ul class="nav nav-treeview" style="padding-left: 25px;">
                <li class="nav-item <?php echo e(\Request::routeIs('users.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('users.index')); ?>" class="nav-link" style="width: 100%">
                        <p>User</p>
                    </a>
                </li>
                <li class="nav-item <?php echo e(\Request::routeIs('branch.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('branch.index')); ?>" class="nav-link" style="width: 100%">
                        <p>Branch</p>
                    </a>
                </li>
                <li class="nav-item <?php echo e(\Request::routeIs('role.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('role.index')); ?>" class="nav-link" style="width: 100%">
                        <p>Role</p>
                    </a>
                </li>
            </ul>
        </li>
        
    </ul>
</nav><?php /**PATH C:\Users\Lenovo Yoga370\Documents\Programming\Personal\aqiqah-management\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>