<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <div class="order_details">
                <p class="order_details_text">
                    <?php echo e($d->packageMenu); ?>

                </p>
                <p class="order_details_helper">
                    Updated 1 day ago
                </p>
            </div>
        </td>
        <td>
            <div class="order_details">
                <p class="order_details_text">
                    <?php echo e($d->customer->name); ?>

                </p>
                <p class="order_details_helper">
                    <?php echo e($d->customer->phone_1); ?>

                </p>
            </div>
        </td>
        <td>
            <div class="order_details">
                <p class="order_details_text">
                    <?php echo e(date('F d, Y', strtotime($d->send_date))); ?>

                </p>
                <p class="order_details_helper">
                    <?php echo e($d->send_time); ?>

                </p>
            </div>
        </td>
        <td>
            <div class="order_details">
                <p class="order_details_text">
                    Dikirim
                </p>
            </div>
        </td>
        <td>
            <div id="detail_icon text-success">
                <a href="<?php echo e(route('order.show', [$d->id])); ?>">
                    <i class="fa fa-eye text-success fa-1x"></i> 
                </a>
            </div>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Lenovo Yoga370\Documents\Programming\Personal\aqiqah-management\resources\views/order/partials/table-list.blade.php ENDPATH**/ ?>