

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<h3>Haloo, <?php echo e(\Auth::user()->name); ?></h3>
		<p><?php echo e(Auth::user()->userCabang); ?></p>
	</div>
</div>
<?php echo $__env->make('test-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- live test card in template -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo Yoga370\Documents\Programming\Personal\aqiqah-management\resources\views/kepala_cabang/index.blade.php ENDPATH**/ ?>