<?php
    $meatId = "";
    $offalId = "";
    $riceId = "";
    $chickenId = "";
    $vegieId = "";
    if ($order != "") {
        $packages = $order->orderPackage[$index];
        $meatId = $order->orderPackage[$index]->package->meat_menu[0]->id;
        $offalId = $order->orderPackage[$index]->package->offal_menu[0]->id;
        $riceId = $order->orderPackage[$index]->package->rice_menu[0]->id;
        $chickenId = $order->orderPackage[$index]->package->chicken_menu[0]->id;
        $vegieId = $order->orderPackage[$index]->package->vegetable_menu[0]->id;
    }
?>
<div class="col-6">
    <label for="">Olahan Daging</label>
    <select name="package[<?php echo e($index); ?>][meat_menu]" class="form-control"
        id="" value="<?php echo e($meatId); ?>">
        <option value="" selected disabled>-- Pilih Olahan Daging --</option>
        <?php $__currentLoopData = $meats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($d->id); ?>"
                <?php echo e($meatId == $d->id ? 'selected' : ''); ?>>
                <?php echo e($d->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-6">
    <label for="">Olahan Jeroan</label>
    <select name="package[<?php echo e($index); ?>][offal_menu]" class="form-control"
        id="" value="<?php echo e($offalId); ?>">
        <option value="" selected disabled>-- Pilih Olahan Jeroan</option>
        <?php $__currentLoopData = $offals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($offal->id); ?>"
                <?php echo e($offalId == $offal->id ? 'selected' : ''); ?>>
                <?php echo e($offal->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-4">
    <label for="">Olahan Ayam</label>
    <select name="package[<?php echo e($index); ?>][chicken_menu]" class="form-control"
        id="" value="<?php echo e($chickenId); ?>">
        <option value="" selected disabled>-- Pilih Olahan Ayam --</option>
        <?php $__currentLoopData = $chickens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chicken): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($chicken->id); ?>"
                <?php echo e($chickenId == $chicken->id ? 'selected' : ''); ?>>
                <?php echo e($chicken->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-4">
    <label for="">Mix Vegetables</label>
    <select name="package[<?php echo e($index); ?>][vegetable_menu]" class="form-control"
        id="" value="<?php echo e($vegieId); ?>">
        <option value="" selected disabled>-- Pilih Mix Vegetable</option>
        <?php $__currentLoopData = $vegies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vegie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($vegie->id); ?>"
                <?php echo e($vegieId == $vegie->id ? 'selected' : ''); ?>>
                <?php echo e($vegie->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-4">
    <label for="">Nasi</label>
    <select name="package[<?php echo e($index); ?>][rice_menu]" class="form-control"
        id="" value="<?php echo e($riceId); ?>">
        <option value="" selected disabled>-- Pilih Nasi --</option>
        <?php $__currentLoopData = $rices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($rice->id); ?>"
                <?php echo e($riceId == $rice->id ? 'selected' : ''); ?>>
                <?php echo e($rice->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div><?php /**PATH C:\Users\Lenovo Yoga370\Documents\Programming\Personal\aqiqah-management\resources\views/order/partials/package4.blade.php ENDPATH**/ ?>