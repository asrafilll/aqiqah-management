<?php
    $meatId = "";
    $riceId = "";
    $chickenId = "";
    if ($order != "") {
        $packages = $order->orderPackage[$index];
        $meatId = $order->orderPackage[$index]->package->meat_menu[0]->id;
        $riceId = $order->orderPackage[$index]->package->rice_menu[0]->id;
        $chickenId = $order->orderPackage[$index]->package->chicken_menu[0]->id;
    }
?>
<div class="col-4">
    <label for="">Olahan Daging</label>
    <select name="package[<?php echo e($index); ?>][meat_menu]" class="form-control"
        id="" value="<?php echo e($meatId); ?>">
        <option value="" selected disabled>-- Pilih Olahan Daging --</option>
        <?php $__currentLoopData = $meats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($d->id); ?>"
                <?php echo e($meatId == $d->id ? 'selected' : ''); ?>>
                <?php echo e($d->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-4">
    <label for="">Oalahan Ayam</label>
    <select name="package[<?php echo e($index); ?>][chicken_menu]" class="form-control"
        id="" value="<?php echo e($chickenId); ?>">
        <option value="" selected disabled>-- Pilih Olahan Ayam</option>
        <?php $__currentLoopData = $chickens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chicken): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($chicken->id); ?>"
                <?php echo e($chickenId == $chicken->id ? 'selected' : ''); ?>>
                <?php echo e($chicken->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-4">
    <label for="">Nasi</label>
    <select name="package[<?php echo e($index); ?>][rice_menu]" class="form-control"
        id="" value="<?php echo e($riceId); ?>">
        <option value="" selected disabled>-- Pilih Nasi --</option>
        <?php $__currentLoopData = $rices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($rice->id); ?>"
                <?php echo e($riceId == $rice->id ? 'selected' : ''); ?>>
                <?php echo e($rice->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div><?php /**PATH C:\Users\Lenovo Yoga370\Documents\Programming\Personal\aqiqah-management\resources\views/order/partials/package7.blade.php ENDPATH**/ ?>