<?php
    $meatId = "";
    $offalId = "";
    if ($order != "") {
        $packages = $order->orderPackage[$index];
        $meatId = $order->orderPackage[$index]->meat->meat->id;
        $offalId = $order->orderPackage[$index]->offal->offal->id;
    }
?>
<div class="col-6">
    <label for="">Olahan Daging</label>
    <select name="package[<?php echo e($index); ?>][meat_menu]" class="form-control"
        id="" value="<?php echo e($meatId); ?>">
        <option value="" selected disabled>-- Pilih Olahan Daging --</option>
        <?php $__currentLoopData = $meats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($d->id); ?>"
                <?php echo e($meatId == $d->id ? 'selected' : ''); ?>>
                <?php echo e($d->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-6">
    <label for="">Olahan Jeroan</label>
    <select name="package[<?php echo e($index); ?>][offal_menu]" class="form-control"
        id="" value="<?php echo e($offalId); ?>">
        <option value="" selected disabled>-- Pilih Olahan Jeroan</option>
        <?php $__currentLoopData = $offals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($offal->id); ?>"
                <?php echo e($offalId == $offal->id ? 'selected' : ''); ?>>
                <?php echo e($offal->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div><?php /**PATH C:\Users\Lenovo Yoga370\Documents\Programming\Personal\aqiqah-management\resources\views/order/partials/package1.blade.php ENDPATH**/ ?>