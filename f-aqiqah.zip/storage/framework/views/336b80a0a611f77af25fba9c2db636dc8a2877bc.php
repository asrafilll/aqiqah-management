<nav class="main-header navbar navbar-expand navbar-white navbar-light">
	<!-- Right navbar links -->
	<ul class="navbar-nav ml-auto">
		<li class="nav-item dropdown">
			<a class="nav-link" data-toggle="dropdown" href="#">
				<?php echo e(\Auth::user()->name); ?>

			</a>
			<div class="dropdown-menu dropdown-menu dropdown-menu-right">
				<!-- <div class="dropdown-divider"></div> -->
				<a href="<?php echo e(route('logout')); ?>" class="nav-link ml-auto" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
					<?php echo e(__('Logout')); ?>

				</a>
				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
					<?php echo csrf_field(); ?>
				</form>
			</div>
		</li>
	</ul>
</nav><?php /**PATH C:\laragon\www\f-aqiqah\resources\views/layouts/nav.blade.php ENDPATH**/ ?>