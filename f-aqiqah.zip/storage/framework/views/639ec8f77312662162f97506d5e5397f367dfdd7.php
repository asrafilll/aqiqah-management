

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<!-- small box -->
		<h3>Haloo, <?php echo e(\Auth::user()->name); ?></h3>
	</div>
	<!-- ./col -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\f-aqiqah\resources\views/ppic/index.blade.php ENDPATH**/ ?>